package com.example.calculoaposentadoria

import android.app.Activity
import android.os.Bundle

import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Spinner

import android.widget.ArrayAdapter

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        var sexo = findViewById<Spinner>(R.id.sexo)
        var idade = findViewById<EditText>(R.id.idade)
        var resultado = findViewById<TextView>(R.id.resultado)
        var botao = findViewById<Button>(R.id.botao)

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("Masculino", "Feminino")
        )
        sexo.adapter = adapter

        botao.setOnClickListener {
            val selec_sexo = sexo.selectedItem as String
            val idade = idade.text.toString().toInt()

            var res = 0

            if (selec_sexo == "Masculino") {
                res = 72 - idade
            }
            else {
                res = 79 - idade
            }
            resultado.text = "Faltam $res anos para você morrer."

        }

    }

}